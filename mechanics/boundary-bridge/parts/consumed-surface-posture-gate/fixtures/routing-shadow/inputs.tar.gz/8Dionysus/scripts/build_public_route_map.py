"""Placeholder fixture file."""
